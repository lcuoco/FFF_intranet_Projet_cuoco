
<!--
Fichier footer-view.inc.php qui contient la vue ddu pied de page et localisé dans le dossier views
de FFF_intranet

-->
<link rel="stylesheet" type="text/css" href="connexion-index.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<div class="footer">
  	<h6>Copiright Cuoco Lucas - Fédération Française de Football</h6>
</div>